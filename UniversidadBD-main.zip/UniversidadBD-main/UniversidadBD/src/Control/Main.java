/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Control;

/**
 *
 * @author Bayron Vargas
 */
import Vista.Ver;
public class Main {
    
    public static void main(String[] args) {
        
        Ver v=new Ver();
        
        v.setVisible(true);
        v.setLocationRelativeTo(null);
        
    }
    
}
